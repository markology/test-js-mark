### Setup

* Install Node 6.1
* Clone repo, cd into directory
* `npm install`

### Run

`npm run start`

### What you need to do

Check out `src/state/actions.js` and add code to fulfill the commented instructions.
